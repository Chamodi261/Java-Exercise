package lesson.pkg51.collection.framwork.hashtable.pkg01;

public class Student {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

   
    public void setName(String name) {
        this.name = name;
    }

   
    public void setAge(int age) {
        this.age = age;
    }

    String getAge() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     
    
}
