package lesson.pkg51.collection.framwork.hashtable.pkg01;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Lesson51CollectionFramworkHashTable01 {

    public static void main(String[] args) {
        Hashtable<Integer,String> hash = new Hashtable();
        
        hash.put(1, " Chamodi");
        hash.put(2," Anne");
        hash.put(3," Devv");
        
        //hash.put(null," Dick");
        //can not hold "null key"
        
        //hash.put(4, null);
        //Can not hold "null value"
        System.out.println(hash);
        
        System.out.println("\n\n-------------------------------------\n\n");

        Hashtable<Integer,Student> hashT = new Hashtable();
        Student std1 = new Student();
        std1.setName("Kamal");
        std1.setAge(26);
        
        Student std2 = new Student();
        std2.setName("Amal");
        std2.setAge(20);
        
        hashT.put(1, std1); // key + value = entry
        hashT.put(2, std2);
        
        Set set = hashT.entrySet();
        
        
        
        Iterator i = set.iterator();
        
        while(i.hasNext())
        {
            Map.Entry<Integer,Student> me = (Map.Entry<Integer,Student>) i.next();
            System.out.println("Key : "+ me.getKey());
            System.out.println("Name : "+me.getValue().getName());
            System.out.println("Age : "+me.getValue().getAge());
        }
        
        
        
        
    }
    
}
