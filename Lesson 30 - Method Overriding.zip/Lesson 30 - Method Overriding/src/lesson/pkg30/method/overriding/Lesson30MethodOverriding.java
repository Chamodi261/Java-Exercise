package lesson.pkg30.method.overriding; 

class A
{
    int i;
    public void show()
    {
        System.out.println("A");
    }
}

class B extends A
{
    
    int i;

    @Override
    
    public void show(){
        System.out.println("B");
        super.show();
        int i = 10;
        super.i = 50;

        System.out.println(i);
        System.out.println(super.i);


    }
}

public class Lesson30MethodOverriding {
    public static void main(String[] args) {
        B obj = new B();
        {
           obj.show();
        }
    }
    
}
