package lesson.pkg39.pkginterface;

public class C {
    
}
