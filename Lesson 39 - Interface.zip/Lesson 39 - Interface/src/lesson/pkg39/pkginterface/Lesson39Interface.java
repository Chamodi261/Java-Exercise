package lesson.pkg39.pkginterface;

public class Lesson39Interface {
    public static void main(String[] args) {
        A a = new A();
        a.getName();
        System.out.println(a.getName());
        
        
        Person p = new A();
        System.out.println(p.getName());
    }
    
}
