package lesson.pkg39.pkginterface;

/*We can only hold abstract metods, variables in the Interface
and can hold final static public variables*/
public interface Person {
    
    //Can not hold these tpe of variable
    //int a; 
    int a = 10;//final static variabl .That means contatnt variable
    
    //Variables should be public.Can not hold private variables
    //private int a =12;
    
    //"Static" mean we can access those variables, without creating an objects
    
    
    
    /*
    
    //Interface can not have body,ecause it is a abstact metod
    String getName()
    {
        System.out.println("");
        return "Hii";
    }
*/
    
    //private String getName() Variables and methods should e public

    public boolean getName();
}
