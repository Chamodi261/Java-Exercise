package lesson.pkg39.pkginterface;
public interface Person_01 {
    
}
