package lesson.pkg39.pkginterface;

//Use the "implements" key words to inherit "Interfface" to the "clazz"

// Inherits Person interface
public class A implements Person,Person_01{ 
   
    @Override
    public String getName(){
       
        return "Chamodi";
    }
}
