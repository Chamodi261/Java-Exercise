/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg19.conditionaal.operators;

/**
 *
 * @author acer
 */
public class Lesson19ConditionaalOperators {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int marks = 60 ;
        System.out.println(marks>50?"Pass":"Fail");
        // TODO code application logic here
    }
    
}
