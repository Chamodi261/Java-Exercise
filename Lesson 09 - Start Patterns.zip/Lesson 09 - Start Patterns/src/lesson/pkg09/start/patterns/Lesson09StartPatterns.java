/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg09.start.patterns;

/**
 *
 * @author acer
 */
public class Lesson09StartPatterns {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Pattern 01");

        for(int i=0;i<=10;i++){
            System.out.print("*");
        }
        
        
        System.out.print("\n\nPattern 02\n");
        
        for(int i =0;i<3;i++){
            for(int j=0;j<3;j++){
                System.out.print("*");
            }
            System.out.print("\n");
        }
        
        System.out.print("\n\nPattern 03\n");
        
        for(int i=0;i<11;i++){
            for(int j=0;j<i;j++){
                System.out.print("*");
            }
            System.out.print("\n");
               
        }
        
        System.out.print("\n\nPattern 04\n");
        
        for(int i=11;i>0;i--){
            for(int j=1; j<=i;j++){
                System.out.print("*");
            }
            System.out.print("\n");
        }

        System.out.print("\n\nPattern 05\n");
        
        for(int i=6;i>0;i--){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.print("\n");
        }
        for(int m=2;m<=6;m++){
            for(int n=1;n<=m;n++){
                System.out.print("*");
            }
            System.out.print("\n");
        }

        System.out.print("\n\nPattern 06\n");

        for(int i=0;i<8;i++){
            for(int j=0;j<=i;j++){
                System.out.print("*");
            }
            System.out.print("\n");
        }
        for(int i=7;i>0;i--){
            for(int j=1; j<=i;j++){
                System.out.print("*");
            }
            System.out.print("\n");
        }

        System.out.print("\n\nPattern 07\n");
        
        for(int i=0;i<10;i++){
            for(int j=10;j>i;j--){
                System.out.print(" ");
            }
            for(int k=0;k<=i;k++){
                System.out.print("* ");
            }
            System.out.print("\n");
        }
        
        System.out.print("\n\nPattern 08\n");
        for(int i=0;i<10;i++){
            for(int j=10;j>i;j--){
                System.out.print(" ");
            }
            for(int k=0;k<=i;k++){
                System.out.print("* ");
            }
            System.out.print("\n");
        }
        for(int i=0;i<10;i++){
            for(int j=0;j<=i;j++){
                System.out.print(" ");
            }
            for(int k=10;k>i;k--){
                System.out.print("* ");
            }
            System.out.print("\n");
        }
        
        System.out.print("\n\nPattern 09\n");
        for(int i=0;i<11;i++){
            for(int j=10;j>=i;j--){
                System.out.print("* ");
            }
            for( int k=0;k<i;k++){
                System.out.print(" ");
            }
            for( int k=0;k<i;k++){
                System.out.print(" ");
            }
            for( int k=0;k<i;k++){
                System.out.print(" ");
            }
            for( int k=0;k<i;k++){
                System.out.print(" ");
            }
            for(int m=10;m>=i;m--){
                System.out.print("* ");
            }
            System.out.print("\n");
        }
        
        System.out.print("\n\nPattern 10\n");

        for(int i=0;i<11;i++){
            for(int j=10;j>=i;j--){
                System.out.print("* ");
            }
            
            for(int k=0;k<i;k++){
                System.out.print(" ");
            }
            for(int k=0;k<i;k++){
                System.out.print(" ");
            }
            for(int k=0;k<i;k++){
                System.out.print(" ");
            }
            for(int k=0;k<i;k++){
                System.out.print(" ");
            }
            for(int l=10;l>=i;l--){
                System.out.print("* ");
            }
            System.out.print("\n");
        }
        
        for(int x=1;x<11;x++){
            for(int y=0;y<=x;y++){
                System.out.print("* ");
            }
            for(int y=10;y>x;y--){
                System.out.print(" ");
            }
            for(int y=10;y>x;y--){
                System.out.print(" ");
            }
            for(int y=10;y>x;y--){
                System.out.print(" ");
            }
            for(int y=10;y>x;y--){
                System.out.print(" ");
            }
            for(int y=0;y<=x;y++){
                System.out.print("* ");
            }
            System.out.println();
        }
        // TODO code application logic here
    }
    
    }
