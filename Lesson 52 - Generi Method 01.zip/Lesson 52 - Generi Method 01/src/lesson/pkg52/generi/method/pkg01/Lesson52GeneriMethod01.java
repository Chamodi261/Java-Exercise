package lesson.pkg52.generi.method.pkg01;

public class Lesson52GeneriMethod01 {

    public static void main(String[] args) {
        
      //  System.out.println(display());
        display("ICT/16/17/016");
        display(11);
        display(12.05);
        System.out.println("\n--------------Generic Method-----------------");

        System.out.println("\nUsing Generic Methads : ");
        generic("Chamodi Dilhara");
        generic(11);
        generic(25.5);
        generic(121);
        generic(10L);
        generic('D');
        generic("HII");
    }
    
    private static void display(String value)
    {
      //  return "Chamodi Dilhara";
        System.out.println(value);
    }
    
    private static void display(Integer value) //method  overloading
    {
        System.out.println(value);
    }
    
    
    private static void display(Double value)
    {
        System.out.println(value);
        
    }

    /*
    Generic Methods mean;
        If some sevaral methods have same body, then we crated a
        generic method.
    */

    
    //System.out.println("--------------Generic Method-----------------");

    //<T> => Type parameter.ten it called generic method
    private static <T> void generic(T value1)
    {
        System.out.print(value1 +" :  ");
        System.out.println(value1.getClass().getName());
    }
}
