package lesson.pkg49.collection.workflow.hash.map.pkg01;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Lesson49CollectionWorkflowHashMap01 {

    public static void main(String[] args) {
        
        HashMap<Integer,String> hm = new HashMap();
        //<Integer,String> ==>  Key of Map -> Integer, Value of Map -> String
        //Key should be a unique
        hm.put(1," Dil");
        hm.put(2," Chami");
        hm.put(4," Shan");
        hm.put(3," Sasa");
        System.out.println(hm);
        Set set = hm.entrySet();
        System.out.println("Using 'Set' : "+set);
        
        System.out.println("\nIterate the 'Set' : ");
        
        Iterator i = set.iterator();
        while(i.hasNext())
        {
            Map.Entry me = (Map.Entry) i.next();
            System.out.println("Key is : "+me.getKey());
            System.out.println("Value is : "+me.getValue());
        }
        System.out.println("Get Value of 'key 01' : "+hm.get(1));
        System.out.println("Get Value of 'key 03' : "+hm.get(3));
        
        hm.put(null, "Saman");
        System.out.println(hm);
   
        hm.put(5, null);
        System.out.println(hm);
        
        //Can hold 'value null' and 'key null'
    }
    
    
}
