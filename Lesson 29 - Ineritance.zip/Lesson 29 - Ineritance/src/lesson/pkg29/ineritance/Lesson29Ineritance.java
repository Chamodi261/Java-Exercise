package lesson.pkg29.ineritance;
public class Lesson29Ineritance {
    public static void main(String[] args) {
       
        Student std = new Student();
        std.print();
        std.id = 2;
        std.print(); 
        std.name = "Camodi";
        std.print();
    }
    
}
