package lesson.pkg29.ineritance;
public class Student extends Human {
     int id = 3890;
       public void print()
     {
        System.out.println("Name : "+name+"\n"+"Age : "+age);
        System.out.println("Id : "+id);
     }
}
