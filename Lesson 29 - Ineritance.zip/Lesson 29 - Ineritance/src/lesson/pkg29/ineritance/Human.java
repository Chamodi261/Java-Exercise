package lesson.pkg29.ineritance;
public class Human {
    
    String name = "Kamal";
    int age = 22;
    
    public void print()
    {
        System.out.println("Name : "+name+"\n"+"Age : "+age);
    }
    
}
