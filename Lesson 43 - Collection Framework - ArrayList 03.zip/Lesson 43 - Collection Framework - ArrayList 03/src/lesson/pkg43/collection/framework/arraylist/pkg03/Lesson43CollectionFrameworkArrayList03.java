package lesson.pkg43.collection.framework.arraylist.pkg03;

import Model.Student;
import java.util.ArrayList;
import java.util.ListIterator;

public class Lesson43CollectionFrameworkArrayList03 {

    public static void main(String[] args) {
        ArrayList<Student> students = new ArrayList<>();
        
        Student std1 = new Student();
        std1.setName("Aamali ");
        std1.setAge(20);
        students.add(std1);
        
        
        Student std2 = new Student();
        std2.setName("Kamal ");
        std2.setAge(25);
        students.add(std2);
        
        System.out.println(students); 
        System.out.println(students.get(1)); 
        System.out.println(students.get(0).getName());
       
        
        //Use list iterator
        System.out.println("\n\nList Iterator....\n");
        ListIterator<Student> myStudent = students.listIterator();
        while(myStudent.hasNext()){
            //hasNext => if there some elements, then it should be true
            Student std = myStudent.next();
            System.out.println("Name : "+std.getName());
            System.out.println("Age  : "+std.getAge());
            
        }
        
    }
    
}
