package lesson.pkg50.collection.workflow.treemap.pkg01;

import java.util.TreeMap;

public class Lesson50CollectionWorkflowTreeMap01 {

    public static void main(String[] args) {
        System.out.println("Tree Map\n");
        
        TreeMap<String,String> TM = new TreeMap();
        //TM = >Variabl's name'
        
        TM.put("Name "," Chamodi");
        TM.put("Name "," Chamodi");//
       // TM.put(null, "Dil");
       // Hash map can hold null key. But Tree Map can not hold null key
        TM.put("Age",null);//Can hold null value, but can not hold null key
        System.out.println(TM);
        
        TM.remove("Age");
        System.out.println("Remove the 'Age' : "+TM);
        
        System.out.println("Find the key 'Name' : "+TM.containsKey("Name "));
        System.out.println("Find the Value 'Chamodi' : "+TM.containsValue(" Chamodi"));
        
        
        TM.replace("Name ", " Dil");
        
        System.out.println("Replacce the Tree Map : "+TM);

    }
    
}
