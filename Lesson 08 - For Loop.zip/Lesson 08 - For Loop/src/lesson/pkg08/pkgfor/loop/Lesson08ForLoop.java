/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg08.pkgfor.loop;

/**
 *
 * @author acer
 */
public class Lesson08ForLoop {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for(int i=1;i<=5;i++){
            System.out.println(i);
        }
        // TODO code application logic here
    }
    
}
