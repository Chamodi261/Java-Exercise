package lesson.pkg45.collection.framework.vector.pkg02;

import java.util.Enumeration;
import java.util.Vector;

public class Lesson45CollectionFrameworkVector02 {

    public static void main(String[] args) {
        Vector<String> v1 = new Vector();
        // Vector v1 = new Vector = Vector<String> v1 = new Vector
        v1.addElement("Saman");
        v1.addElement("Kamal");
        v1.addElement("Raani");
        
        System.out.println(v1);
        System.out.println("Index of Kamal : "+v1.indexOf("Kamal"));
        System.out.println("First Element : " +v1.firstElement());
        System.out.println("Last Element : "+v1.lastElement());
        System.out.println("Clone the Vector : "+v1.clone());
     //   System.out.println("Last Index of : "+v1.lastIndexOf("Kamal"));
        System.out.println("Index of 2 : "+v1.elementAt(2));
        System.out.println("Remove Kamal : "+v1.remove("Kamal")+"\t==>\t"+v1);
        
        System.out.println("\nFor loop Iteration : ");
        for(String vec: v1){
            System.out.println(vec);
        }
        
        System.out.println("\nAnoter type to iteration : ");
        Enumeration e = v1.elements();
        while (e.hasMoreElements())
            //if tere more elements, then wile being true
        {
           System.out.println(e.nextElement()); 
        }
                
        
        
    }
    
}
