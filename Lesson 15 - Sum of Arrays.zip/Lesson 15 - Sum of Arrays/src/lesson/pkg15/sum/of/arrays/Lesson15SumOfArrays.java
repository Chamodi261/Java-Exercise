/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg15.sum.of.arrays;

/**
 *
 * @author acer
 */
public class Lesson15SumOfArrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int i,j = 0;
        int m,n,x,y = 0;
       int[][] arry1 = {{12,15,21},{30,45,25}};
       System.out.println("Array 01");
       for(i=0;i<2;i++){
           for(j=0;j<3;j++){
               System.out.print(arry1[i][j]+" ");
           }
       System.out.println();
       }
       
       int[][] arry2 = {{21,10,5},{57,26,35}};
       System.out.println("\n\nArray 02");
       for(x=0;x<2;x++){
           for(y=0;y<3;y++){
               System.out.print(arry2[x][y]+" ");
           }
           System.out.println();
       }
      
       System.out.println("\n\nSum of Array");
       int sum=0;
       
       int[][] arry3 = new int[2][3];
       for(m=0;m<2;m++){
            for(n=0;n<3;n++){
               sum = arry1[m][n] + arry2[m][n];
               arry3[m][n]=sum;
               System.out.print(arry3[m][n]+" ");
           }
             System.out.println();
       }
// TODO code application logic here
    }
    
}
