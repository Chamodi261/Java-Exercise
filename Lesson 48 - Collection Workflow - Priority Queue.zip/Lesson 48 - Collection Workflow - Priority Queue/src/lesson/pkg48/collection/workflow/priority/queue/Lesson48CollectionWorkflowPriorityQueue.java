package lesson.pkg48.collection.workflow.priority.queue;

import java.util.PriorityQueue;

public class Lesson48CollectionWorkflowPriorityQueue {

    public static void main(String[] args) {
        
        PriorityQueue<String> PQueue = new PriorityQueue();

        System.out.println("Queue is : "+PQueue.peek());
        System.out.println("Poll is : "+PQueue.poll());
        //System.out.println("Removing  is : "+PQueue.remove());
        

        PQueue.add("Hello");
        PQueue.add("Chamodi");
        PQueue.add("Hello");
        PQueue.add("Dil");
        PQueue.add("Hello");

        System.out.println("Element is : "+PQueue.element());//First element in the uue

        System.out.println(PQueue);
        
        
        System.out.println("Peek Element is : "+PQueue.peek());
        System.out.println("Remove : "+PQueue.remove());//Remove te first element
        System.out.println("After Removing Queue is : "+PQueue);
        
        System.out.println("Poll: "+PQueue.poll());
        System.out.println("After Polling Queue is : "+PQueue);
        
        PQueue.offer("Sasa");
        PQueue.offer("Lanii");

        System.out.println("After Offering Queue is : "+PQueue);
        System.out.println("Removing : "+PQueue.remove());
        System.out.println("After Removing : "+PQueue);

        
    
        
    }
    
}
