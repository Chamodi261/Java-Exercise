package lesson.pkg40.pkginterface.example;

public class Temp {
    
    
    public void getPersonDetails(CommonPerson P)
    {
        System.out.println("\nMethod 02:");
        System.out.println(P.getName());
        System.out.println(P.getAge());
    }

   

  
   
}
