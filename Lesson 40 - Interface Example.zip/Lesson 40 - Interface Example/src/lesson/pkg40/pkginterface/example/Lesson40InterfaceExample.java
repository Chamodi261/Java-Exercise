package lesson.pkg40.pkginterface.example;

public class Lesson40InterfaceExample {

    public static void main(String[] args) {
        
        Temp t = new Temp(); 
        Person P = new Person();
        t.getPersonDetails(P);
    }
    
}
