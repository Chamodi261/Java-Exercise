package lesson.pkg40.pkginterface.example;

public interface CommonPerson {
    
    public abstract String getName();
    public abstract int getAge();
}
