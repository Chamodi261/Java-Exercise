package lesson.pkg40.pkginterface.example;

public class Person implements CommonPerson  {
    
    String name = "Chamodi";
    int age = 26;
    String password = "ABC";

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getAge() {
    return age;
    }
}
