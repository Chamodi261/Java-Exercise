package lesson.pkg26.methodoverloading_02;
public class Lesson26MethodOverloading_02 {
    public static void main(String[] args) {
        //addTwoNumbers(50,60);
        addTwoNumbers(200L,356L); // "L" mean long metod
        
        System.out.println(addTwoNumbers(100,150));
    }
    
    public static double addTwoNumbers(int x1, int x2)
    {
        double sum = x1 + x2;
        System.out.println("This is int metod:");
        return sum;
    }
    
    public static double addTwoNumbers(long x1, long x2)
    {
        double sum = x1 + x2;
        System.out.println("Sum 2: "+sum);
        return sum; 
    }
    
}
