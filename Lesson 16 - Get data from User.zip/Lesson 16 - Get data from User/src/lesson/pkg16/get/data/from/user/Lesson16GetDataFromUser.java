/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg16.get.data.from.user;
import java.util.Scanner;
/**
 *
 * @author acer
 */
public class Lesson16GetDataFromUser {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner i = new Scanner(System.in);
       int j = i.nextInt();
       System.out.println(j+"");
       
       System.out.println("Arrayn\n");
       int[][] arry = new int[3][3];
       
       Scanner x = new Scanner(System.in);
       for(int a=0;a<3;a++){
           for(int b=0;b<3;b++){
               System.out.print("Enter your "+a+","+b+" element: ");
               arry[a][b] = x.nextInt();
           }
       }
       
       for(int p=0;p<3;p++){
           for(int q=0;q<3;q++){
               System.out.print(arry[p][q]+" ");
           }
           System.out.println();
       }
    }
}    

