package lesson.pkg44.collection.framework.vector.clz.pkg01;

import java.util.Vector;

public class Lesson44CollectionFrameworkVectorCLz01 {

   public static void main(String[] args) {
       Vector v = new Vector();//create a vector
       System.out.println("Capacity of the Vector : "+v.capacity());
       System.out.println("Size of the Vector : "+v.size());
       
       System.out.println("\n\nBy using add :");
       for(int i=0;i<8;i++)
       {
           v.add(i);
       }           
       System.out.println(v);
       System.out.println("Capacity of the vector : "+v.capacity());
       System.out.println("Size of the vector : "+v.size());

       
       //Vector 02
       Vector v1 = new Vector();
       
       System.out.println("\n\nBy using addElement :");
        for(int a=0;a<15;a++)
       {
           v1.add(a);
       }
       System.out.println(v1);
       System.out.println("Capacity of the vector : "+v1.capacity());
       System.out.println("Size of the vector : "+v1.size());

   }
    
}
