
package lesson.pkg23.methodoverloading;
public class Lesson23MethodOverloading {
    public static void main(String[] args) {
        Lesson23MethodOverloading ob = new Lesson23MethodOverloading();
        ob.sum();
        ob.sum(10);
        ob.sum(34+51);

    }
    public void sum()
    {
        System.out.println("Sum");
    }
    
    public void sum (int a)
    {
        System.out.println("a = "+ a);
    }
    
    public void sum(int a,int b)
    {
        int sum = a+b;
        System.out.println("Sum is : "+sum);
    }
}
