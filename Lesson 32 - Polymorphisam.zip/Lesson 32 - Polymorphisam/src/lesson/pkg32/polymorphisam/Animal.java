package lesson.pkg32.polymorphisam;
public class Animal {
    public String eat()
    {
       return "Animal Eating Foods"; 
        
    }
}
