package lesson.pkg32.polymorphisam;
public class Rabbit extends Animal {
    public String eat()
    {
        return "Rabbit Eats Carrots";
    }
}
