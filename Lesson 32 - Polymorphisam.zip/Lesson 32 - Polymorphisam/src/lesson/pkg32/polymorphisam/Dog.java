package lesson.pkg32.polymorphisam;
public class Dog extends Animal{
    public String eat(){
        return "Dog Eats Meets";
    }
}
