package lesson.pkg32.polymorphisam;
public class Lesson32Polymorphisam {
    public static void main(String[] args) {
        
        Animal obj1 = new Rabbit();
        Animal obj2 = new Dog();
        System.out.println(obj1.eat());
        System.out.println(obj2.eat());
    }
    
}
