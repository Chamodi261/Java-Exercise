class Sum
{
	public static void main(String[] args)
	{
		int sum =0;
		int mul =1;
		
		//int mul = args[0];
		for(String val:args)
		{
			sum = sum + Integer.parseInt(val);
			mul = mul * Integer.parseInt(val);
			System.out.println(val);
		}
		System.out.println("Sum is :  "+sum);
		System.out.println("Multiplication is :  "+mul);
	
	}
}