package lesson.pkg35.aceess.modifier.pkgprotected;

import ABC.Pig;

public class Lesson35AceessModifierProtected {

    public static void main(String[] args) {
        Pig pig = new Pig();
        System.out.println("Pig's Age : "+pig.age);
        System.out.println("Second Type :" + pig.getAge());
    }
    
}
