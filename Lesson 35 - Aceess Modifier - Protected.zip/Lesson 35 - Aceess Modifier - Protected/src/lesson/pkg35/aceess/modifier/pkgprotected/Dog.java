package lesson.pkg35.aceess.modifier.pkgprotected;
public class Dog extends Animal{
    public int getAge(){
        return super.age;
    }
}
