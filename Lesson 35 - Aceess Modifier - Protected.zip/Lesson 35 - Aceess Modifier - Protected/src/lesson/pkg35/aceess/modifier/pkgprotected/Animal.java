package lesson.pkg35.aceess.modifier.pkgprotected;
public class Animal {
    
    protected int age = 18;
    public int getAge(){
        return this.age;
    }
    
}
