package lesson.pkg35.aceess.modifier.pkgprotected;
public class Rabbit {
    Animal ani =  new Animal();
    public int getAge()
    {
        return ani.age;
    }
}
