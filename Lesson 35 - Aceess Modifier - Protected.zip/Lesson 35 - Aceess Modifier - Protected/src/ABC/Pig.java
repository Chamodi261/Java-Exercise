package ABC;

import lesson.pkg35.aceess.modifier.pkgprotected.Animal;

public class Pig extends Animal{
    public int getAge(){
        return super.age;
    }
            
}
