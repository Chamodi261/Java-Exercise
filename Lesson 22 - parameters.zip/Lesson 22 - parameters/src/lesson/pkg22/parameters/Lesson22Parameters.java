
package lesson.pkg22.parameters;
public class Lesson22Parameters {
    public static void main(String[] args) {
        int x =10, y = 50;
        Lesson22Parameters ob = new Lesson22Parameters();
        int summ = ob.sum(x,y);
        System.out.println(summ);
        
        int subb = ob.sub(x, y);
        System.out.println(subb);
    }
    public int sum(int a, int b)
    {
        int sum = a+b;
        return sum;
    }
    
    
    public int sub(int a, int b)
    {
        int sum = a-b;
        return sum;
    }
}
