package lesson.pkg54.bounded.type.parameters;

public class Lesson54BoundedTypeParameters {

    public static void main(String[] args) {
        System.out.println("Bounded Tyep Parameters -> We can limit the passed object,  \n\n");
       // display("Chamodi");
        display(20);
        //display('C');
        display(15.25);
        display(10L);
        
        System.out.println("--------------------------\n");
        dis("Chamodi");
        dis("A");
        dis("Mala");
       // dis(18);
      // dis('B');
         dis("C");
    }
    
    private static <T extends Number> void display(T value)
            //Object limits for only "Numbers"
    {
       System.out.println(value+" :  "+value.getClass().getName());
    }
    
    private static <T extends String> void dis(T val)
    {
        System.out.println(val+" :  "+val.getClass().getName());
    }
}
