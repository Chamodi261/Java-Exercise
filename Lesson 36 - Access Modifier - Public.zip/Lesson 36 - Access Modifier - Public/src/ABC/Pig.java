package ABC;

import lesson.pkg36.access.modifier.pkgpublic.Animal;

public class Pig {
    Animal ani = new Animal();
    public int getAge()
    {
        return ani.age;
    }
    
}
