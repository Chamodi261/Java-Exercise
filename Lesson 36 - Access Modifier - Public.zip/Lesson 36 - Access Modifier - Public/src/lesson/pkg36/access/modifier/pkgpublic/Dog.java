package lesson.pkg36.access.modifier.pkgpublic;

public class Dog extends Animal {
    
    public int getAge()
    {
        return super.age;
    }
    
}
