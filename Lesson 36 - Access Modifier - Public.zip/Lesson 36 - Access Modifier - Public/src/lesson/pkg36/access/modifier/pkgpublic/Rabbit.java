package lesson.pkg36.access.modifier.pkgpublic;
public class Rabbit {

    Animal annni = new Animal();
    public int getAge()
    {
        return annni.age;
    }
    
}
