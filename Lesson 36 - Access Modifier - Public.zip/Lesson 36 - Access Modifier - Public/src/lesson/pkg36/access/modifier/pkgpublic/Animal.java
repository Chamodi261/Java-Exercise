package lesson.pkg36.access.modifier.pkgpublic;
public class Animal {
    public int age = 25;
    public int getAge(){
        return this.age;
    }
}
