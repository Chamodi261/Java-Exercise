package lesson.pkg36.access.modifier.pkgpublic;

import ABC.Pig;

public class Lesson36AccessModifierPublic {
    public static void main(String[] args) {
        
        Pig pig = new Pig();
        System.out.println(pig.getAge());
    }
    
}


