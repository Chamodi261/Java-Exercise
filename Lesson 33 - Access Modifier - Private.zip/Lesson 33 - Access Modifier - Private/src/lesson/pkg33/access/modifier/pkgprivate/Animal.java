package lesson.pkg33.access.modifier.pkgprivate;
public class Animal {
    
    private int age = 25;
    public int getAge(){
        return this.age;
    }
    
    String name = "Camodi";

    
}
