package lesson.pkg33.access.modifier.pkgprivate;
public class Dog extends Animal{
    public int getAge()
    {
        return super.getAge();
    }
}
