package lesson.pkg33.access.modifier.pkgprivate;
public class Lesson33AccessModifierPrivate {
    public static void main(String[] args) {
        Animal obj = new Animal();
        System.out.println(obj.getAge());
        System.out.println(obj.name);
        
        Dog dog = new Dog();
        System.out.println(dog.getAge());
    }
     
}
