package lesson.pkg27.constructor;
public class A {
    /*Constructor haven't any return type. That methos create by it's 
    class's name**/
    
    
    //Constructor
    A(){
        /*  1. No return type
            2. Name by it's class name's
        */
        System.out.println("This is a Constructor");
    }
    
    
}
