package lesson.pkg27.constructor;
public class Lesson27Constructor {
    public static void main(String[] args) {
        
        A ob = new A();
        
        
    }
    
}
