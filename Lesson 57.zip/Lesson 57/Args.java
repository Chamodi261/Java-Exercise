class Args
{
	public static void main(String[] args)
	{
		for(String val:args)
		{
			System.out.println(val);
		}
	}
}