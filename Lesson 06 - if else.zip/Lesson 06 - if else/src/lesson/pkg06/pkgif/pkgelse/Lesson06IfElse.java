/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg06.pkgif.pkgelse;

/**
 *
 * @author acer
 */
public class Lesson06IfElse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int x =8 ;
        if(x>=8){
            System.out.println("x is greater than 8");
        }
        else{
            System.out.println("x is less than 8");
        }
        // TODO code application logic here
    }
    
}
