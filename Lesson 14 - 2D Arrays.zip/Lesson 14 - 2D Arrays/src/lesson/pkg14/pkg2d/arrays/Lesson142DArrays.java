 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg14.pkg2d.arrays;

/**
 *
 * @author acer
 */
public class Lesson142DArrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Method 01\n");

        int[][] arry = new int[2][3];
        arry[0][0] = 15;
        arry[0][1] = 54;
        arry[0][2] = 20;
        arry[1][0] = 45;
        arry[1][1] = 10;
        arry[1][2] = 25;
        
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                System.out.print(arry[i][j]+" ");
            }
            System.out.print("\n");
        
        }
        
        
        System.out.println("\nMethod 02\n");
        
        int[][] arr = {{12,45,70},{25,54,30}};
        for(int x=0;x<2;x++){
            for(int y=0;y<3;y++){
                System.out.print(arr[x][y]+" ");
            }
            System.out.println();
        }
        
        
        // TODO code application logic here
    }
    
}
