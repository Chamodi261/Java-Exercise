
package lesson.pkg24.local.and.globaal.variable;
public class Lesson24LocalAndGlobaalVariable {
    static int j=20;
    public static void main(String[] args) {
        int i =10;
        System.out.println(i);
        System.out.println(j);
        sum();
     }
    public static void sum()
    {
        System.out.println(j);
    }
}
