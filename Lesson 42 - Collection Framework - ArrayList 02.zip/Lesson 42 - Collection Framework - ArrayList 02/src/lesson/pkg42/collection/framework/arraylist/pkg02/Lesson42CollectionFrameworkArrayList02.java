package lesson.pkg42.collection.framework.arraylist.pkg02;

import java.util.ArrayList;
//import java.util.List;

public class Lesson42CollectionFrameworkArrayList02 {

    public static void main(String[] args) {
        
        
        ArrayList<String> names = new ArrayList<>();
        
        names.add("Chamodi");
        names.add("Mala");
        names.add("Soyaa");
        names.add("Gamage");
        names.add("Ranii");
        
        for(String name:names)
        {
            System.out.println(name);
        }
        
        System.out.println("\n"+names);
        
        //Count the data
        System.out.println("\nCount the data : \n");
        System.out.println("Array List Size is : "+names.size());
        names.add(1,"Malani");
        names.add(4,"Vihaga");
        names.add(0,"Buddikaa");
        names.add(0,"Lakshan");
                
        //Find some names in array
        System.out.println("\nFind some names in array :");
        System.out.println(names.contains("\n"+"Chamodi"));
        System.out.println(names.contains("Chamodi\nDilhara"));

        //Clear the array list
        System.out.println("\nClear the array list : ");
        ArrayList<String> array = new ArrayList<>();
        
        array.add("Dilhara");
        array.add("Mala");
        array.add("Soyaa");
        
        System.out.println(array);       
        array.clear();
        System.out.println("Array is : "+array);
        System.out.println("Array Size : "+array.size());
        
        //Get valuue of 1st index
        System.out.println("\nGet value of 1st index : ");
        System.out.print("1st index value of **NAMES** array :");
        System.out.println(names.get(0));
        
        //get index of some array
        System.out.println("\nGet index of array : ");
        System.out.println("Index of Soyaa : "+names.indexOf("Soyaa"));

        //Remove an element
        System.out.println("\nRemove an Element Metod 01: ");
        System.out.println("Before removing : "+ names);
        System.out.println("Remove [2] : "+ names.remove(2));
        System.out.println("After Removing : "+names);
        
        System.out.println("\nRemove an Element Metod 02: ");
        System.out.println("Before removing : "+ names);
        System.out.println("Remove **Vihaga** : "+ names.remove("Vihaga"));
        System.out.println("After Removing : "+names);
        

    }
    
}
 