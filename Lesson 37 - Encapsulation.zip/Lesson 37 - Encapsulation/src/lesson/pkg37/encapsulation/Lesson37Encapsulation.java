package lesson.pkg37.encapsulation;
public class Lesson37Encapsulation {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.setAge(15);
        cat.setName("Kitty");
        cat.setFood("Fish");
        System.out.println("Name : "+cat.getName()+"\n"+"Age  : "+cat.getAge()+"\n"+"Food : "+cat.getFood());
       
    }
    
}
