package lesson.pkg37.encapsulation;
public class Cat {
    //Encapsulation mean; Data Hiding
    private int age = 10;
    private String name;
    private String food;
    
    public void setAge(int age)//Setter
    {
        this.age = age;
    }
    
    public int getAge()//Getter
    {
        return this.age;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }
    
    
    
}
