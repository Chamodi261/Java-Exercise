
package lesson.pkg21.work.wit.several.methods;
public class Lesson21WorkWitSeveralMethods {
    public static void main(String[] args) {
        Lesson21WorkWitSeveralMethods ob = New Lesson21WorkWitSeveralMethods();
        
    }
    public void abc(){        // Create a metod and named it "abc"
        System.out.println("NEw Metod");  
    }
}
