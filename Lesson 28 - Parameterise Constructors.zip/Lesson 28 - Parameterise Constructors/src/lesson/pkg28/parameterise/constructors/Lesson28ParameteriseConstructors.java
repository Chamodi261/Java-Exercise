package lesson.pkg28.parameterise.constructors;
public class Lesson28ParameteriseConstructors {
    public static void main(String[] args) {
        Clz_01 ob1 = new Clz_01();
        Clz_01 ob2 = new Clz_01(10); 
        Clz_01 ob3 = new Clz_01(13,15);
        Clz_01 ob4 = new Clz_01(20,50,15);
                
    }
    
}
