package lesson.pkg28.parameterise.constructors;

import static javafx.scene.input.KeyCode.Y;

public class Clz_01 {
    
    Clz_01() //Default Constructor
    {
        System.out.println("Tis is a Constructors");
    }
    
    Clz_01(int x) //Parameterise Constructors
    {
        System.out.println("x is = "+x);
    }
    
    Clz_01(int x, int y)
    {
        System.out.println("X is : "+x+"\t"+"Y is : "+y);
    }
    
    Clz_01(int x, int y, int z)
    {
        int sum= x+y+z;
        System.out.println("Sum is : "+sum);
    }
             
}
