package lesson.pkg20.oop;
public class NewClass {
    public void m() //m = method's name
    {
        System.out.println("Hello");    
    }
}
