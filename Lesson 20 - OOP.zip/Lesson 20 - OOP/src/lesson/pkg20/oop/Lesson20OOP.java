package lesson.pkg20.oop;
public class Lesson20OOP {
    public static void main(String[] args) {
        NewClass ob; // Create a object as "ob"
        ob = new NewClass();
        //NewClass ob = new NewClass();
        
        ob.m();//ob. => in the NewClass
   }
    
}
