package lesson.pkg47.treeset.pkg01;

import java.util.Iterator;
import java.util.TreeSet;

public class Lesson47TreeSet01 {

    public static void main(String[] args) {
            
        TreeSet<String>  ts = new TreeSet();
        //Daata Stored as assending order
        ts.add("Amal");
        ts.add("Chamodi");
        ts.add("Lakshan");
        ts.add("Liyanage");
        ts.add("Sasanka");
        ts.add("Mala");
        ts.add("Ranji"); 
        ts.add("Aasi");
        ts.add("Mala"); // No Duplicate Values
        ts.add("Binali");
        System.out.println(ts);
        
        System.out.println("\nIterator : ");
        Iterator it = ts.iterator();
        while(it.hasNext())
        {
            System.out.println(it.next());
        }
        
        System.out.println("\nFirst Element : "+ts.first());
        
        
        
    }
    
}
