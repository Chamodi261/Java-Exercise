package lesson.pkg46.collection.framework.linkdlist.pkg01;

import java.util.LinkedList;

public class Lesson46CollectionFrameworkLinkdList01 {


    public static void main(String[] args) {
        LinkedList list1 = new LinkedList();
        list1.add("A");
        list1.add("B");
        list1.add("C");
        list1.add("E");
        list1.add("G");
        list1.addLast("O"); // Add elements in to last index
        list1.addFirst("Z"); // add elements into first index
        list1.add(2,"H"); // add "H" into 2nd element
        System.out.println(list1+"\n");
        
        System.out.println("Before Removing Any Elements : "+list1);

        list1.removeFirst();//remoe first element
        System.out.println("Remove 1st Element : "+list1);
        list1.removeLast(); //remove last element
        System.out.println("Remove Last Element : "+list1);
        
        Object v1 = list1.get(1);
        System.out.println(v1);
        list1.set(1,(String) v1+" Changed Value : ");
        System.out.println(list1);
        
       
    }
    
}
