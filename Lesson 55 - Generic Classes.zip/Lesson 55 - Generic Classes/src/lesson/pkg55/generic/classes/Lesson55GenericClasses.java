package lesson.pkg55.generic.classes;

    class Test<T,U>//Multiple tye "Type-Paraameter"
    {
       private  T obj;
       private U obj1;
       
        Test(T obj, U obj1)
        {
            this.obj = obj;
            this.obj1 = obj1;
        }
        //When hae mutiple "Type-Parameters"
        
        public void print(){
            System.out.println("Obj   : "+this.obj);
            System.out.println("Obj 1 : "+this.obj1);
        }
/*
//Whaen have single "Type-Parameter"
        public T getObject()
        {
            return this.obj;
           // return this.obj1;
        }
*/
    }
public class Lesson55GenericClasses {

    public static void main(String[] args) {
/*
        Test<String> sObj = new Test<String>("Chamo");
        System.out.println(sObj.getObject());
        
        Test<Integer> iObj = new Test<Integer>(12);
        System.out.println(iObj.getObject());
*/
        Test<String,Integer> sobj = new Test<String,Integer>("Dil",22);
        sobj.print();
    }
    private static <T> void disply(T value)
    {
        System.out.println(value.getClass().getName());
    }
}
