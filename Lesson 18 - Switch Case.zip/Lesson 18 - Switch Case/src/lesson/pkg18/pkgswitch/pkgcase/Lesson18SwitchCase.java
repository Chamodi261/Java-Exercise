/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg18.pkgswitch.pkgcase;

/**
 *
 * @author acer
 */
public class Lesson18SwitchCase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i =2;
        switch(i)
        {
            case 1:
                System.out.println("One");
            break;
            
            case 2:
                System.out.println("Two");
            break;
            
            case 3:
                System.out.println("Three");
            break;
            
            default:
                System.out.println("Invalid");
        }
        
    }
    
}
