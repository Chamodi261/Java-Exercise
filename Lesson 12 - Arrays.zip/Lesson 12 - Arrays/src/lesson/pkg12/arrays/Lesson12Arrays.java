 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lesson.pkg12.arrays;

/**
 *
 * @author acer
 */
public class Lesson12Arrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int[] myarray={12,25,45,52,57,30};
        int sum=0;
        float avg;
        for(int i=0;i<6;i++){
            System.out.println(myarray[i]+"");
            sum=sum+myarray[i];
        }
        
        System.out.println("\nSum is: "+ sum);
        avg=(float)sum/6;
        System.out.println("Average is: "+avg);
        
        //Replace the Array
        System.out.println("\n\nReplace the Array");
        myarray[0]=50;
        for(int x=0;x<6;x++){
            System.out.print(myarray[x]+" ");
            sum=sum+myarray[x];

        }
        
        System.out.println("\nSum is: "+ sum);
        avg=(float)sum/6;
        System.out.println("Average is: "+avg);
        
        System.out.println("\n");
        
        int[] arry = new int[5];
        arry[0] = 25;
        arry[2] = 54;
        arry[1] = 10;
        arry[4] = 30;
        arry[3] = 68;
        int sum1 = 0;
        float avg1;
        for(int i=0;i<5;i++){
            System.out.print(arry[i]+" ");
            sum1=sum1+arry[i];
        }
        System.out.println("\nNew Sum is: "+sum1);
        avg1=(float)sum1/5;
        System.out.println("New Average is: "+avg1);
        
        System.out.println("\n\nArray Sorting");
        int arr[] = new int[5];
        arr[0]=34;
        arr[1]=67;
        arr[4]=78;
        arr[3]=53;
        arr[2]=10;
        int temp=0;
        
        System.out.print("Before Sorting:");
        for(int i=0;i<5;i++){
            System.out.print(arr[i]+" ");
            for(int a=0;a<5;a++){
                if (arr[i]>arr[a]){
                }

                else{
                    temp = arr[i];
                    arr[i]=arr[a];
                    arr[a]=temp;
                }
            }
       }
        
        
        System.out.print("\n\nAfter Sorting: ");

        for(int j=0;j<5;j++){
            System.out.print(arr[j]+" ");
        }
        
      
        
    }
}