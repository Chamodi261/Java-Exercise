package lesson.pkg25.oop.example;
public class Lesson25OOPExample {
    public static void main(String[] args) {
        
    }
    
}
