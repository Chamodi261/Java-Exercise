package lesson.pkg38.abstraction;

/*
People is a abstract clz
Engineer is a concreate clz
There for we can not extends concreate clz by using abstrat clzz.*/

/*If we want to do these we have fallow two methods.
    1. We can convert the "Concreate clz" into "Abstrat Clz".
    2. We can "Override" the abstract method, that created in 
    abstract clzz*/

//Method 01
/*
public abstract class Engineer extends People
{
}
*/
//Method 02
public class Engineer extends People{
/*add constructor*/
    public Engineer(String Name, double Cash) {
        super(Name, Cash);
    }

    @Override
    public double getIncome() {
        return super.getCash()*30;
    }
    
}
