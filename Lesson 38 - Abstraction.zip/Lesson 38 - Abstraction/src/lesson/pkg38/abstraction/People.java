package lesson.pkg38.abstraction;

public abstract class People {
/*if some clss have abstract method,
    then this clss must be a abstract class.
ut tis abstrat class can hold a non abstract-class.these class are known 
as "Concreate Class"*/
    
    //Abstract Method
    public abstract double getIncome();

    //Concreate Method
    private String Name;/*Tese two classes are in private.
    So we have to Encapsulation these methods*/
    private double Cash;
    
    //Make a Constrctor
    People(String Name, double Cash)
    {
        this.Cash = Cash;
        this.Name = Name;
    }
    
    
        

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public double getCash() {
        return Cash;
    }

    public void setCash(double Cash) {
        this.Cash = Cash;
    }
}
