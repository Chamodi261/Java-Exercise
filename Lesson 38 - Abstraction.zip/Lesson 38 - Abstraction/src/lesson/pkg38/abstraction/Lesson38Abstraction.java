
package lesson.pkg38.abstraction;
public class Lesson38Abstraction {
    public static void main(String[] args) {
        
        //People Ple = New People();
        /*We can not make a objects by using
        abstract class*/
        
        People p = new Engineer("Chamodi",1000); // Pass the constructor
        /*Can not make a object by using abstract clz.
        But we can create a object by using sub clz of tose abstract clz*/
        
        System.out.println(p.getIncome());
        System.out.println(p.getName());
    }
    
}
