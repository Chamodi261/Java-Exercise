package ABC;

import lesson.pkg34.access.modifier.pkgdefault.Animal;

/*public class Pig {
    Animal animal = new Animal();
    public int getAge()
    {
       return animal.age;
    }
            
}*/
