package lesson.pkg34.access.modifier.pkgdefault;
public class Animal {
    
    int age = 06; // default access modifier
    public int getAge(){
        return this.age;
    }
}
