package lesson.pkg34.access.modifier.pkgdefault;
public class Rabbit {

    Animal ob = new Animal();
    public int getAge(){
        return ob.age;
    }
    
}
