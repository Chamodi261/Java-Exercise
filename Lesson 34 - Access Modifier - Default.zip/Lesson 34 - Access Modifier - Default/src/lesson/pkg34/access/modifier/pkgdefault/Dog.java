package lesson.pkg34.access.modifier.pkgdefault;
public class Dog extends Animal{
    
    public int getAge()
    {
        return super.age;
    }
    
}
