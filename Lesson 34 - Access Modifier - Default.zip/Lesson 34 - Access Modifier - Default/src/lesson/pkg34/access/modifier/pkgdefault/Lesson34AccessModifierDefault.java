package lesson.pkg34.access.modifier.pkgdefault;
public class Lesson34AccessModifierDefault {
    public static void main(String[] args) 
    {
        /*Animal obj = new Animal();
        System.out.println(obj.getAge());
        
        Dog dog = new Dog();
        System.out.println(dog.getAge());*/
        
        Rabbit ob = new Rabbit();
        System.out.println(ob.getAge());
    }
    
}
    
 