package lesson.pkg53.generic.method.pkg02;

public class Lesson53GenericMethod02 {

    public static void main(String[] args) {
        //Integer type aray
        
        Integer[] intArray = {1,2,3,4};
        display(intArray);
        
        Character[] charArray = {'C','H','O','K','M'};
        display(charArray);
        
        String[] stArray = {"Orange","Banana","Apple","Mango","Star-Fruit","Kiwi"};
        display(stArray);

    }
    
    private static <T> void display(T[] array)
            //T[] => for pass the array use "[]"after the "T"
    {
        for(T element:array){
            System.out.printf("%s ",element);
        }
        System.out.println("\n");
    }
    
}
